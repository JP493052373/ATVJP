<?php
try {
    $conexao = new PDO("mysql:host=localhost; dbname=PROJETOWEB", "root", "");
} catch (PDOException $e) {
    die("Ocorreu um erro inesperado " . $e->getMessage());
}

$nome = $_POST['nome'];
$nota = $_POST['nota'];

try {
    $sql = "insert into campus (NOTA, nomeCurso) values ('$nota', '$nome')";
    $conexao->exec($sql);
    echo "Salvo com sucesso !!!";
} catch (PDOException $e) {
    die("Ocorreu um erro " . $e->getMessage());
}
header('Location: ../../view/curso/buscarCurso.php');
