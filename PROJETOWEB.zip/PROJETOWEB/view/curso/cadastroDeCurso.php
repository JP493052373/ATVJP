<!DOCTYPE html>
<html lang="en">
<?php $path = 'http://' . $_SERVER["HTTP_HOST"] . '/PROJETOWEB'; ?>

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Curso</title>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <link href="../../arquivos/css/bootstrap.min.css" rel="stylesheet">
    <script src="../../arquivos/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="../../arquivos/js/busca.curso.js"></script>
</head>

<body>
    <?php include("../../menu.php") ?>
    <div class="p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle  rounded-3">
        <div class="container">
            <div class="row mb-4 mt-4">
                <div class="alert alert-light" role="alert">
                    <h1>Cadastro de Curso</h1>
                </div>
            </div>
            <form action="<?php echo $path; ?>/repositorio/curso/salvarCurso.php" method="POST">
                <div class="container">
                    <form method="POST">
                        <div class="row">
                            <div class="row mb-4">


                                <div class="col col-md-8">
                                    <label for="idnome">NOME:</label>
                                    <input class="form-control" id="idnome" type="text" name="nome"><br>
                                </div>
                                <div class="col col-md-4">
                                    <label for="idnome">NOTA:</label>
                                    <input class="form-control" id="idnota" type="number" name="nota"><br>
                                </div>
                            </div>
                            <div class="row mb-3">




                                <input class="btn btn-primary" type="submit" id="button" value="Salvar">

                            </div>



                    </form>
                </div>
        </div>

</body>

</html>