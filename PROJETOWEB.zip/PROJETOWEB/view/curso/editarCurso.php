<?php
try {
    $conexao = new PDO("mysql:host=localhost; dbname=PROJETOWEB", "root", "");
} catch (PDOException $e) {
    die("Ocorreu um erro inesperado " . $e->getMessage());
}

$idCurso = $_POST['idcurso'];
$nome = $_POST['nome'];
$nota = $_POST['nota'];

try {
    $sql = "update curso set nomeCurso='$nome', nota='$nota' where idCurso=" . $idCurso;
    $conexao->exec($sql);
    echo "Editado com sucesso!";
} catch (PDOException $e) {
    die("Ocorreu um erro " . $e->getMessage());
}

header('Location: ../../view/curso/buscarCurso.php');
