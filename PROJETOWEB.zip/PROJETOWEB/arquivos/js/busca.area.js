$(document).ready(function() {

    function limpa_formulário_area() {
       
        $("#idnome").val("");
        
    }
    
    //Quando o campo cep perde o foco.
    $("#idnome").blur(function() {

        //Nova variável "cep" somente com dígitos.
        var nome = $(this).val().replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (nome != "") {

            //Expressão regular para validar o CEP.
            var validnome = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                $("#idnome").val("...");
                $("#idbairro").val("...");
                $("#idcidade").val("...");
                $("#iduf").val("...");

                //Consulta o webservice viacep.com.br/
                $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados) {

                    if (!("erro" in dados)) {
                        //Atualiza os campos com os valores da consulta.
                        $("#idrua").val(dados.logradouro);
                        $("#idbairro").val(dados.bairro);
                        $("#idcidade").val(dados.localidade);
                        $("#iduf").val(dados.uf);
                    } //end if.
                    else {
                        //CEP pesquisado não foi encontrado.
                        limpa_formulário_area();
                        alert("nome não encontrado.");
                    }
                });
            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_area();
                alert("Formato de nome inválido.");
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_area();
        }
    });
});